using System;
using UnityEngine;
using UnityEngine.UI;
using NA.CrossPlatformInput;
using ControlFreak2;
//using MoreMountains.NiceVibrations;
using NA;
using DG.Tweening;
using UnityStandardAssets.Utility;
using static LevelManager;

namespace NA.Vehicles.Ball
{
    public class BallUserControl : SimpleSingleton<BallUserControl>
    {
        private Ball ball; // Reference to the ball controller.
        public LayerMask groundLayers;
        [SerializeField]
        //private Transform[] rotatingBall;
        public float rotationSpeed;
        private Vector3 move;
        // the world-relative desired move direction, calculated from the camForward and user input.
        public  Rigidbody rb;
        private Transform cam; // A reference to the main camera in the scenes transform
        private Vector3 camForward; // The current forward direction of the camera
                                    // private bool jump; // whether the jump button is currently pressed
        public Transform t;
        [SerializeField] private float m_TurnSmoothing = 10f;

        private float ballLookAngle;
      //  private float ballTurnSpeed = 1.5f;

        private Quaternion m_TransformTargetRot;
        private Quaternion m_PivotTargetRot;

        public Vector3 previousPos;
        public Vector3 cameraTarget;
        private Transform bT;

        public Transform followFrefab;

      //  public DynamicJoystick dJS;
        public InputManager input;
        public float h;
        public float v;

        bool jump;
        public bool onPipes;
        bool isSoundPlaying;
        public float velocity;
        public float velocityX;
        // ..............Sounds ............

        public AudioSource rollingSound;
        public AudioSource pipeRollingSound;
        public AudioSource groundHitsound;
        public Transform rotation;
        // ........ Particles ........
        public ParticleSystem groundHitEffect;
        int ballIndex;
        Vector3 lookPos;
        Quaternion rot;
      //  Vector3 prevInput;
      // Vector3 curInput;
        public Button playButton;
        public bool gameStart;
        public Transform ballLocation;

        public GameObject coinanimPrefab;
        public GameObject keyAnimPrefab;
        public GameObject coinsTextPrefab;
      //  public GameObject keyTextPrefab;
        public Transform mainCanvas;
        private float inputTimer;
        //public GameObject dirArrow;
        float hr = 0.0f;
        float vr = 0.0f;
        float x = 0.0f;
        float z = 0.0f;
        float xSpeed = 0.0f;
        float zSpeed = 0.0f;
        Vector3 pos;
        Vector3 dir;
        Vector3 zForward;
        public GameObject[] particlesPrefabs;

        public bool StopInput = false;

        private void OnEnable()
        {
            Time.timeScale = 1.0f;
            TryGetComponent(out bT);
            // Set up the reference.
            TryGetComponent(out ball);
            TryGetComponent(out rb);
            m_PivotTargetRot = transform.localRotation;
            m_TransformTargetRot = transform.localRotation;
            // get the transform of the main camera
            if (Camera.main != null)
            {
                cam = Camera.main.transform;
            }
            else
            {
                Debug.LogWarning(
                    "Warning: no main camera found. Ball needs a Camera tagged \"MainCamera\", for camera-relative controls.");
                // we use world-relative controls in this case, which may not be what the user wants, but hey, we warned them!
            }

            ballIndex = PlayerPrefs.GetInt("selectedball");
            //for (int i = 0; i < rotatingBall.Length; i++)
            //{
            //    if (i == ballIndex)
            //    {
            //        rotatingBall[i].gameObject.SetActive(true);
            //    }
            //    else
            //    {
            //        rotatingBall[i].gameObject.SetActive(false);
            //    }

            //}
            t.SetLocalPositionAndRotation(transform.position, transform.rotation);
            UpdateParticles();

        }

        public void UpdateBall()
        {
            ballIndex = PlayerPrefs.GetInt("selectedball");
            //for (int i = 0; i < rotatingBall.Length; i++)
            //{
            //    if (i == ballIndex)
            //    {
            //        rotatingBall[i].gameObject.SetActive(true);
            //    }
            //    else
            //    {
            //        rotatingBall[i].gameObject.SetActive(false);
            //    }

            //}
        }

        public void UpdateParticles()
        {
            int a = PlayerPrefs.GetInt("particles");
            if (a == 0)
            {
                return;
            }
            else
            {
                particlesPrefabs[a - 1].gameObject.SetActive(true);
            }
        }

        public void PlayCoinAnim()
        {
            // Debug.Log("PlayAnim");
            GameObject c = Instantiate(coinanimPrefab, t);
            GameObject tx = Instantiate(coinsTextPrefab, mainCanvas);
            tx.SetActive(true);
            Destroy(c, 1.0f);
            Destroy(tx, 1.0f);

            // t.GetComponent<Animator>().Play("CoinAnimNew");
        } 
        public void PlayKeyAnim()
        {
            // Debug.Log("PlayAnim");
            GameObject c = Instantiate(keyAnimPrefab, t);
            GameObject tx = Instantiate(coinsTextPrefab, mainCanvas);
            tx.SetActive(true);
            Destroy(c, 1.0f);
            Destroy(tx, 1.0f);

            // t.GetComponent<Animator>().Play("CoinAnimNew");
        }

        public float FrameCounter = 0;
        private void FixedUpdate()
        {
            #region StopAction Region
            if (StopInput)
            {
                h = 0;
                v = 0;
                rb.angularDrag = 1;
                rb.drag = 1;

                if (rb.maxAngularVelocity >= 0)
                {
                    rb.maxAngularVelocity -= Time.fixedDeltaTime * 40f;
                }

                t.position = transform.position;
                return;
            }
            #endregion
            // upward stop Action

            // Update()
            ////h = input.horizontal;
            ////v = input.vertical;
            
            if(CF2Input.GetAxis("Fire1")>0)
            {
                FrameCounter += Time.fixedDeltaTime;
                Debug.Log("Mouse Y Value  " + v +"  Frames "+FrameCounter);
                h = CF2Input.GetAxis("Mouse X");
                v = CF2Input.GetAxis("Mouse Y");
            }
            else
            {
                if (FrameCounter <= 0.1f && v>=1f)
                {
                    ball.ShootBall = true;
                    Debug.Log("Shoot " );
                }
                    FrameCounter = 0;
                h = CF2Input.GetAxis("Mouse X");
                v = CF2Input.GetAxis("Mouse Y");
            }
            
            //if(h>1f)
            //    h= 1f;
            //if (v>1)
            //{
            //    v = 1;
            //}
            //if (h < -1f)
            //    h = -1f;
            //if (v < -1)
            //{
            //    v = -1;
            //}
            //Debug.Log("H value"+h+" V "+v);

            //if (h == 0 && v == 0 && Mathf.Abs(rb.velocity.x) < 2.0f && Mathf.Abs(rb.velocity.z) < 2.0f)
            //{
            //    inputTimer += Time.fixedDeltaTime;
            //    if (inputTimer > 1f)
            //    {
            //        //   dirArrow.SetActive(true);
            //    }
            //    else 
            //    {
            //        //dirArrow.SetActive(false);
            //    }
            //}
            //else
            //{
            //    inputTimer = 0;
            //    //dirArrow.SetActive(false);
            //}
            if (v > 0.2f && !gameStart)
            {
                playButton.onClick.Invoke();
            }
            if (!gameStart)
                return;
            //if (h < 0.01f && h > -0.01)//for Quick Response
            //{
            //    h = 0f;


            //}

            //ballLookAngle += h*2;//* ballTurnSpeed;

            // Rotate the rig (the root object) around Y axis only:
            //m_TransformTargetRot = Quaternion.Euler(0f, ballLookAngle, 0f);
            // calculate move direction
            if (cam != null)
            {
                // calculate camera relative direction to move:
                camForward = Vector3.Scale(cam.forward, new Vector3(1, 0, 1)).normalized;
                move = (v * camForward + h * cam.right).normalized;
                //    Debug.Log("v = " + v + " hm = " + h);
            }
            else
            {
                // we use world-relative directions in the case of no main camera
                move = (v * Vector3.forward + h * Vector3.right).normalized;
            }

            // velocity = Mathf.Abs(rb.velocity.z);
            //  velocityX = Mathf.Abs(rb.velocity.x);


            //if (velocity < 0.8f && velocity > -0.8f)
            //{
            //    velocity = 0f;
            //}
            //Update end
          //  hr = input.horizontal;
          //  vr = input.vertical;
          //  curInput = new Vector3(vr, 0, hr);
            t.position = transform.position;
            //  Debug.Log("Velocity X,Y = x =" + velocityX + " y " + velocity);
            //if (Mathf.Abs(velocity)==0f&& Mathf.Abs(velocityX) == 0f)
            //{
            //    lookPos = curInput- prevInput ;
            //    previousPos = curInput;
            //}

            //else
            //{
            lookPos = followFrefab.position - t.position;
            //}
            // lookPos = followFrefab.position - t.position;

            lookPos.y = 0;
            rot = Quaternion.LookRotation(lookPos);
            t.rotation = Quaternion.Slerp(t.rotation, rot, Time.deltaTime * 10.0f);


            xSpeed = Mathf.Abs(rb.velocity.x);
            zSpeed = Mathf.Abs(rb.velocity.z);
            //Comment by Qasim as sound and rotation use nhi krni
            #region Sound Track Off
            //if (xSpeed > zSpeed)
            //{
            //    rotatingBall[ballIndex].Rotate(Mathf.Abs(rb.velocity.x * rotationSpeed), 0, 0, Space.Self);
            //    if (!jump && Mathf.Abs(rb.velocity.x * rotationSpeed) > 5f)
            //    {
            //        if (!rollingSound.isPlaying)
            //        {
            //            rollingSound.Play();
            //        }
            //        else
            //        {

            //            float pitch = Mathf.Abs(rb.velocity.x);

            //            if (pitch > 10f)
            //            {
            //                rollingSound.pitch = 2.0f;
            //                rollingSound.volume = (Mathf.Abs(rb.velocity.x));
            //            }
            //            else
            //            {
            //                rollingSound.volume = (Mathf.Abs(rb.velocity.x));
            //                rollingSound.pitch = (pitch / 10f) + 1;
            //            }

            //        }

            //    }
            //    else
            //    {
            //        if (rollingSound.isPlaying)
            //        {
            //            rollingSound.Stop();
            //        }

            //        if (onPipes)
            //        {
            //            if (!pipeRollingSound.isPlaying)
            //            {
            //                pipeRollingSound.Play();
            //            }
            //            else
            //            {
            //                float pitch = Mathf.Abs(rb.velocity.x);
            //                if (pitch > 10f)
            //                {
            //                    pipeRollingSound.pitch = 2.0f;
            //                    pipeRollingSound.volume = (Mathf.Abs(rb.velocity.x) / 40);
            //                }
            //                else
            //                {
            //                    pipeRollingSound.volume = (Mathf.Abs(rb.velocity.x) / 40);
            //                    pipeRollingSound.pitch = (pitch / 10f) + 1;
            //                }
            //            }
            //        }
            //    }
            //}
            //else
            //{
            //    rotatingBall[ballIndex].Rotate(Mathf.Abs(rb.velocity.z * rotationSpeed), 0, 0, Space.Self);
            //    if (!jump && Mathf.Abs(rb.velocity.z * rotationSpeed) > 5f)
            //    {
            //        if (!rollingSound.isPlaying && Mathf.Abs(rb.velocity.z * rotationSpeed) > 0.8f)
            //        {
            //            rollingSound.Play();
            //        }
            //        else
            //        {

            //            float pitch = Mathf.Abs(rb.velocity.z);

            //            if (pitch > 10f)
            //            {
            //                rollingSound.pitch = 1.20f;
            //                rollingSound.volume = (Mathf.Abs(rb.velocity.z));
            //            }
            //            else
            //            {

            //                rollingSound.volume = (Mathf.Abs(rb.velocity.z));
            //                rollingSound.pitch = 1f;
            //            }
            //        }

            //    }
            //    else
            //    {
            //        if (rollingSound.isPlaying)
            //        {
            //            rollingSound.Stop();
            //        }
            //        if (onPipes)
            //        {
            //            if (!pipeRollingSound.isPlaying)
            //            {
            //                pipeRollingSound.Play();
            //            }
            //            else
            //            {


            //                float pitch = Mathf.Abs(rb.velocity.z);

            //                if (pitch > 10f)
            //                {
            //                    pipeRollingSound.pitch = 1.20f;
            //                    pipeRollingSound.volume = (Mathf.Abs(rb.velocity.z) / 80);
            //                }
            //                else
            //                {

            //                    pipeRollingSound.volume = (Mathf.Abs(rb.velocity.z) / 80);
            //                    pipeRollingSound.pitch = 1f;
            //                }
            //            }
            //        }
            //    }
            //}
            #endregion

            RaycastHit hit;
            if (Physics.Raycast(transform.position, -Vector3.up, out hit, 1.0f, groundLayers))
            {
                if (jump)
                {
                    groundHitsound.Play();
                    groundHitEffect.transform.SetPositionAndRotation(hit.point, groundHitEffect.transform.rotation);
                    groundHitEffect.Play();


                }

                jump = false;

            }
            else
            {
                jump = true;

            }



            if (!Mathf.Approximately(0f, Vector3.Distance(previousPos, bT.position)))
            {
                pos = previousPos;
                dir = (transform.position - previousPos).normalized;


                zForward = pos + dir * 10;
                followFrefab.position = new Vector3(zForward.x, zForward.y, zForward.z);
                cameraTarget = pos + dir * 10;

                previousPos = bT.transform.position;
            }
            // Call the Move function of the ball controller



            x = Mathf.Abs(h);
            z = Mathf.Abs(v);
            //if(h!=0 || v != 0)
            //{

            //    ball.Move(move,1);

            //}
            //else
            //{
            //    ball.Move(move, 0);
            //}
            if (x >= z)
            {
                //if (rb.velocity.x > 0f && h < 0f)
                //{
                ball.Move(move, Mathf.Clamp01(x), false);
                //Debug.Log("Reverse x Greater");
                //}
                //else if (rb.velocity.x < 0f && h > 0f)
                //{
                //    ball.Move(move, Mathf.Clamp01(x), false);
                //    //Debug.Log("Reverse x Less");
                //}
                //else
                //{
                //    ball.Move(move, Mathf.Clamp01(x), false);
                //}

            }
            else
            {
                //if (rb.velocity.z > 0f && v < 0f)
                //{
                ball.Move(move, Mathf.Clamp01(z), false);
                //}
                //else if (rb.velocity.z < 0f && v > 0f)
                //{
                //    ball.Move(move, Mathf.Clamp01(z), false);
                //}
                //else
                //{
                //    ball.Move(move, Mathf.Clamp01(z), false);
                //}

            }


        }


        public void Jump(float power)
        {
            ball.Jump(power);
        }

        public void SpawnPlayer(Transform to)
        {
            // Debug.Log("Spawn Player Run");
            transform.SetPositionAndRotation(new Vector3(to.position.x, to.position.y + 0.5f, to.position.z), to.rotation);
            t.SetLocalPositionAndRotation(transform.position, Quaternion.identity);
            Invoke("isKinameticFalse", 0.2f);
           SmoothFollow.Instance.CameraOnBack();

        }

        public void ReSpawnPlayer(Transform to)
        {
            //for (int i = 0; i < rotatingBall.Length; i++)
            //{

            //    rotatingBall[i].gameObject.SetActive(false);


            //}
            transform.SetPositionAndRotation(new Vector3(to.position.x, to.position.y + 0.5f, to.position.z), to.rotation);
            t.SetLocalPositionAndRotation(transform.position, transform.rotation);
            //LevelManager.Instance.ballIcon.gameObject.SetActive(true);
            //LevelManager.Instance.ballIcon.position = LevelManager.Instance.chanceImages[LevelManager.Instance.chance].transform.position;
            //LevelManager.Instance.ballIcon.DOMove(ballLocation.position, 1.0f).OnComplete(() => ReSpawnEvent(to));



            //  rb.isKinematic = false;

        }

        public void ReSpawnEvent(Transform to)
        {
            for (int i = 0; i < LevelManager.Instance.playerBalls.Length; i++)
            {
                LevelManager.Instance.playerBalls[i].SetActive(false);
            }
            switch (LevelManager.Instance.BallType)
            {
                case SwitchBallType.Origional:
                    LevelManager.Instance.PaperBall.SetActive(false);
                    LevelManager.Instance.MetalBall.SetActive(false);
                    LevelManager.Instance.playerBalls[PlayerPrefs.GetInt("selectedball")].SetActive(true);

                    break;
                case SwitchBallType.MetalBall:
                    LevelManager.Instance.PaperBall.SetActive(false);
                    LevelManager.Instance.MetalBall.SetActive(true);
                    break;
                case SwitchBallType.PaperBall:
                    LevelManager.Instance.PaperBall.SetActive(true);
                    LevelManager.Instance.MetalBall.SetActive(false);
                    break;

            }

            //for (int i = 0; i < LevelManager.Instance.playerBalls.Length; i++)
            //{
            //    if (i == ballIndex)
            //    {
                    
            //        LevelManager.Instance.playerBalls[i].gameObject.SetActive(true);
            //    }
            //    else
            //    {
            //        LevelManager.Instance.playerBalls[i].gameObject.SetActive(false);
            //    }

            //}
            LevelManager.Instance.ballIcon.gameObject.SetActive(false);

        }

        public void PlayButton()
        {
            SmoothFollow.Instance.distance = SmoothFollow.Instance.GamePlayCamera.Distance;
            SmoothFollow.Instance.height = SmoothFollow.Instance.GamePlayCamera.HeightSub;
            //SmoothFollow.Instance.reachDamping = 1.5f; 
            //SmoothFollow.Instance.heightDamping = 50f;
            SmoothFollow.Instance.reachDamping = SmoothFollow.Instance.GamePlayCamera.ReachDamping;
            SmoothFollow.Instance.heightDamping = SmoothFollow.Instance.GamePlayCamera.HeightDamping;
            SmoothFollow.Instance.startMove = true;
            gameStart = true;
            rb.isKinematic = false;
            Invoke("MoveStart", 0.1f);
        }


        public void MoveStart()
        {
            ball.Move(Vector3.forward, 10.0f, false);
        }
    }
}
