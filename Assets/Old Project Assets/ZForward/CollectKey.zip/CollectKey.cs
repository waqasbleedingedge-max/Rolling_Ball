using NA.Vehicles.Ball;
using NA;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectKey : MonoBehaviour
{
    public float ontriggerEnterDelay;
    public string[] tags;
    private BallUserControl bsu;

    //  public UnityEvent OnTriggerEnterEvent;
    // public UnityEvent OnTriggerEnterEventInstant;
    //  public UnityEvent OnTriggerExitEvent;
    private void OnTriggerEnter(Collider other)
    {
        foreach (string tag in tags)
        {
            if (other.CompareTag(tag))
            {
                // OnTriggerEnterEventInstant.Invoke();
                bsu = other.GetComponent<BallUserControl>();
                bsu.PlayKeyAnim();
                CoinsManager.Instance.AddCoins(10);
                Invoke("End", 0.1f);
            }

        }
    }

    private void End()
    {
        Destroy(this.gameObject);
    }
}
