using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class OnTriggerBoxHitSound : MonoBehaviour
{

    public UnityEvent BoxTrigger;

    public void OnCollisionEnter(Collision collision)
    {
        if (collision.transform.CompareTag("Player"))
        {
           // Debug.Log("BoxHit");
            BoxTrigger.Invoke();
        }
    }
}
