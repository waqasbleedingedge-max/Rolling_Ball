
using GoogleMobileAds.Api;

abstract class AdsManager 
{
    #region Top Banner
    public abstract void AssignTopBannerPoition(AdPosition adPosition);
    public abstract void LoadTopBanner();
    public abstract bool IsLoadTopBanner();
    public abstract bool IsAlreadyShowTopBanner();
    public abstract void ShowTopBanner();
    public abstract void HideTopBanner();
    public abstract void ChangePositionBanner();
    #endregion
    #region Bottom Banner
    public abstract void AssignBottomBannerPoition(AdPosition adPosition);
    public abstract void LoadBottomBanner();
    public abstract bool IsLoadBottomBanner();
    public abstract bool TempIsLoadBottomBanner();
    public abstract bool IsAlreadyShowBottomBanner();
    public abstract void ShowBottomBanner();
    public abstract void ChangePositionBottomBanner(AdPosition adPosition);
    public abstract void HideBottomBanner();
    #endregion
    #region Big Bottom Banner
    public abstract void AssignBigBannerPoition(AdPosition adPosition);
    public abstract void LoadBigBanner();
    public abstract bool IsLoadBigBanner();
    public abstract bool IsLoadBigBannerForLoop();
    public abstract bool IsAlreadyShowBigBanner();
    public abstract void ShowBigBanner();
    public abstract void HideBigBanner();
    #endregion
    #region AppOpen

    public abstract void LoadAppOpenAd();
    public abstract bool IsAppOpenLoaded();
    public abstract void ShowAppOpen();
    public abstract void RequestAppOpen();
    #endregion
}
