using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class AppOpenManager : MonoBehaviour
{
    public static AppOpenManager instance;

    private void Awake()
    {
        instance = this;
    }
    #region AppOpen Ids
    [Header("Admob AppOpen Ids")]
    [Space(10)]

    [SerializeField] string AdmobHighAppOpenId;
    [SerializeField] string AdmobMedAppOpenId;
    [SerializeField] string AdmobLowAppOpenId;
    #endregion
    #region Test AppOpen Id
    [Header("Admob Test AppOpen Id")]
    [Space(10)]

    [SerializeField] string AppOpenTestID;
    #endregion
    #region Handlers


    AdmobMonotization HighAppOpen;
    AdmobMonotization MedAppOpen;
    AdmobMonotization LowAppOpen;
    #endregion
    public bool isTesting, RemoveAds;
    public static bool ForeGroundedAD;
    //public Text LHigh_Info, LMed_Info, LLow_Info;
    //public int LHigh_InfoValue, LMed_InfoValue, LLow_InfoValue;
    // Start is called before the first frame update
    void Start()
    {
        if (isTesting)
        {


            HighAppOpen = new AdmobMonotization(AppOpenTestID, 0);
            MedAppOpen = new AdmobMonotization(AppOpenTestID, 1);
            LowAppOpen = new AdmobMonotization(AppOpenTestID, 2);
        }
        else
        {

            HighAppOpen = new AdmobMonotization(AdmobHighAppOpenId, 0);
            MedAppOpen = new AdmobMonotization(AdmobMedAppOpenId, 1);
            LowAppOpen = new AdmobMonotization(AdmobLowAppOpenId, 2);
        }
    }
    bool RemoveAdsChecker()
    {
        if (RemoveAds)
            return true;
        else
            return false;
    }
    #region AppOpen Ad
    public void LoadAppOpenAd()
    {
        if (RemoveAdsChecker())
            return;

        //Admob
        //LHigh_InfoValue += 1;
        //LHigh_Info.text = "Load HighAppOpen " + LHigh_InfoValue;
        HighAppOpen.LoadAppOpenAd();
        //LMed_InfoValue += 1;
        //LMed_Info.text = "Load MedAppOpen " + LMed_InfoValue;
        MedAppOpen.LoadAppOpenAd();
        //LLow_InfoValue += 1;
        //LLow_Info.text = "Load LowAppOpen " + LLow_InfoValue;
        LowAppOpen.LoadAppOpenAd();
    }
    public void ShowAppOpenAd()
    {
        if (RemoveAdsChecker())
            return;

        PrioritySettingAppOpen();
    }
    void PrioritySettingAppOpen()
    {
        if (!SwitchAppOpen(0))
        {
            if (!SwitchAppOpen(1))
            {
                if (!SwitchAppOpen(2))
                {
                }
            }
        }
    }
    

    bool SwitchAppOpen(int Priority)
    {
        switch (Priority)
        {

            case 0:
                if (HighAppOpen.IsAppOpenLoaded())
                {
                    ActiveAppOpenImage();
                   // HideAllBanners();
                    ForeGroundedAD = true;
                    HighAppOpen.ShowAppOpen();
                    return true;
                }
                else
                {
                    //LHigh_InfoValue += 1;
                    //LHigh_Info.text = "Load HighAppOpen " + LHigh_InfoValue;
                    HighAppOpen.LoadAppOpenAd();
                    return false;
                }

            case 1:
                if (MedAppOpen.IsAppOpenLoaded())
                {
                    ActiveAppOpenImage();
                   // HideAllBanners();
                    ForeGroundedAD = true;
                    MedAppOpen.ShowAppOpen();
                    return true;
                }
                else
                {
                    //LMed_InfoValue += 1;
                    //LMed_Info.text = "Load MedAppOpen " + LMed_InfoValue;
                    MedAppOpen.LoadAppOpenAd();
                    return false;
                }
            case 2:
                if (LowAppOpen.IsAppOpenLoaded())
                {
                    ActiveAppOpenImage();
                   // HideAllBanners();
                    ForeGroundedAD = true;
                    LowAppOpen.ShowAppOpen();
                    return true;
                }
                else
                {
                    //LLow_InfoValue += 1;
                    //LLow_Info.text = "Load LowAppOpen " + LLow_InfoValue;
                    LowAppOpen.LoadAppOpenAd();
                    ForeGroundedAD = true;
                    return false;
                }
            case 99:
                return false;
            default:
                return false;
        }
    }
    void ActiveAppOpenImage()
    {
        //CanvesObj.SetActive(true);
        //if (isNoInternetPanelPortrait == 1)
        //{
        //    AppOpenBGScreenPotrate.SetActive(true);
        //    Invoke(nameof(DeactiveAppOpenImage), .5f);
        //}
        //else
        //{
        //    AppOpenBGScreen.SetActive(true);
        //    Invoke(nameof(DeactiveAppOpenImage), .5f);
        //}

    }
    void DeactiveAppOpenImage()
    {
        //CanvesObj.SetActive(false);
        //ForeGroundedAD = false;
        //AppOpenBGScreen.SetActive(false);
        //AppOpenBGScreenPotrate.SetActive(false);
        //ShowClosedBannersAll();
    }
    private void OnApplicationPause(bool isPaused)
    {
        if (!isPaused)
        {

            if (SceneManager.GetActiveScene().buildIndex == 0) 
            {
                return;
            }
            if (!ForeGroundedAD)
            {
                ShowAppOpenAd();
            }
            else
            {
                ForeGroundedAD = false;
            }
        }
    }
    
    #endregion

}
