﻿////using GameAnalyticsSDK;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using GoogleMobileAds.Api;
using GoogleMobileAds.Ump.Api;
using GoogleMobileAds.Common;
using Firebase.Sample.Analytics;
using UnityEngine.Events;
using SolarEngine;

public class AdmobAdsManager : MonoBehaviour
{
    public static AdmobAdsManager Instance;

    public static bool InAppClick;
    public static bool ForeGroundedAD;
    public UnityEvent OnCallAdmobInitilized;
    public bool Internet;
    public bool Check_Firebase;
    public bool Ads_Purchase;
    public String SdkKey;
    public String InterID;
    public String RewardedID;
    public static event Action onInitializeEvent;
    public string[] TestDevices;
    public Text _log,NewLogsForconsent,Track;
    public Action RewardHandle;
    public Action NotRewardHandle;
    public bool isRewarded = false;
    [HideInInspector]
    public bool InitSucceded;
    public bool AdShown = false;
    public bool RemoveAds = false;
    private static DateTime Time1ForAds;
    private static DateTime TimeForInterAds;
    public bool IsInterstitialAdReady = false;
    public bool HardLevelCheck;

    // bool  IsAppOpenAdAvailable=false;
    bool  trytoInitializeOnceMore=false;
    public bool isAdmobInitialized, ConsentPanelAlreadyShow;
    //public FirstLoading loadingScreen;
    public GameObject Canves, RewardLoadingPanel, AppOpenLoading, NoInternetPanelLandscap,AlreadyBuyThisPanel;
    public bool DontShowAds;
    public Text AdmobText,FirbaseText,TopBannerText, BottomBannerText,BigBannerText, InterText, RewardText,IAP_Text;
    //public HideGameObject hideGame;
    public Text LHigh_Info, LMed_Info, LLow_Info;
    public Text SHigh_Info, SMed_Info, SLow_Info;
    public Text High_HInfo, Med_HInfo, Low_HInfo;
    public Text HisloadInfo, MisloadInfo, LisloadInfo;
    public int LHigh_InfoValue, LMed_InfoValue, LLow_InfoValue;
    public int High_InfoValue, Med_InfoValue, Low_InfoValue;
    public int High_HInfoValue, Med_HInfoValue, Low_HInfoValue;
    void Awake()
    {
        if (Application.isEditor)
        {
            Debug.unityLogger.logEnabled = true;
        }
        else
        {
            Debug.unityLogger.logEnabled = false;
        }

        

        Instance = this;
        DontDestroyOnLoad(this.gameObject);

        StartCoroutine(Btn_Internet());
        AdsInitilizes();
        if (PlayerPrefs.GetInt("GDPRConsentAd")!=0)
        {
            OnClose_consentForm();
            
        }
        else
        {
            GetGDPR_Consent();
            
        }
        if (PlayerPrefs.GetInt("removeads") == 0)
            RemoveAds = false;
        else
            RemoveAds = true;
    }


    // Start is called before the first frame update
    void Start()
    {
        

        if (Test_Ads)
        {
            ADMOB_ID = TestAdmob_ID;
        }
        else
        {
#if UNITY_ANDROID
            ADMOB_ID = AndroidAdmob_ID;

#endif
        }

        

        setTimeForInterAds();
    }

    
    




    #region Admob 
    public bool Test_Ads;
    public AdmobId AndroidAdmob_ID = new AdmobId();
    public AdmobId TestAdmob_ID = new AdmobId();
    [HideInInspector]
    public AdmobId ADMOB_ID = new AdmobId();



    #region Handlers
    AdmobMonotization HighTopBanner;
    AdmobMonotization MedTopBanner;
    AdmobMonotization LowTopBanner;

    AdmobMonotization HighBottomBanner;
    AdmobMonotization MedBottomBanner;
    AdmobMonotization LowBottomBanner;

    AdmobMonotization HighBigBanner;
    AdmobMonotization MedBigBanner;
    AdmobMonotization LowBigBanner;

    AdmobMonotization HighAppOpen;
    AdmobMonotization MedAppOpen;
    AdmobMonotization LowAppOpen; 
    #endregion

    public int CurrentTopBannerShow;
    public int CurrentBottomBannerShow;
    public int CurrentBigBannerShow;
    AdPosition BottomBannerAdPosition = AdPosition.Bottom;
    private void AdmobInit()
    {
        if (!isAdmobInitialized)
        {
            isAdmobInitialized = true;
            // Track.text = "Start AdmobInit call " + Time.timeScale;
            AdmobText.text = "Start_Initializing";
            Debug.Log("GG >> Admob:Start_Initializing");
            MobileAds.Initialize((initStatus) =>
            {
                Debug.Log("GG >> Admob:Initialized");



                Dictionary<string, AdapterStatus> map = initStatus.getAdapterStatusMap();
                foreach (KeyValuePair<string, AdapterStatus> keyValuePair in map)
                {
                    string className = keyValuePair.Key;
                    AdapterStatus status = keyValuePair.Value;
                    switch (status.InitializationState)
                    {
                        case AdapterState.NotReady:
                            // The adapter initialization did not complete.

                            Debug.Log("GG >> Adapter: " + status.Description + " not ready.Name=" + className);

                            //      Logging.Log("Adapert is :: "+(AdmobGAEvents.AdaptersNotInitialized) + className);

                            break;
                        case AdapterState.Ready:
                            // The adapter was successfully initialized.
                            Debug.Log("GG >> Adapter: " + className + " is initialized.");
                            // Track.text = " AdmobInit initialized " + Time.timeScale;
#if UNITY_ANDROID

                            MediationAdapterConsent(className);
#endif


                            break;
                    }
                }



                isAdmobInitialized = true;

            });
            
        }
        Invoke(nameof(AfterAdmobInit), 1);
    }
    private void AfterAdmobInit()
    {
        StartCoroutine(FireBaseInitialize());
        
    }
    void AdsInitilizes()
    {
        if (Test_Ads)
        {

            HighTopBanner = new AdmobMonotization(TestAdmob_ID.ADMOB_TopBANNER_AD_ID[0]);
            MedTopBanner = new AdmobMonotization(TestAdmob_ID.ADMOB_TopBANNER_AD_ID[1]);
            LowTopBanner = new AdmobMonotization(TestAdmob_ID.ADMOB_TopBANNER_AD_ID[2]);

            HighBottomBanner = new AdmobMonotization(TestAdmob_ID.ADMOB_BottomBANNER_AD_ID[0], AdPosition.Bottom);
            MedBottomBanner = new AdmobMonotization(TestAdmob_ID.ADMOB_BottomBANNER_AD_ID[1], AdPosition.Bottom);
            LowBottomBanner = new AdmobMonotization(TestAdmob_ID.ADMOB_BottomBANNER_AD_ID[2], AdPosition.Bottom);

            HighBigBanner = new AdmobMonotization(TestAdmob_ID.ADMOB_BigBANNER_AD_ID[0], AdPosition.Center,"bigbanner");
            MedBigBanner = new AdmobMonotization(TestAdmob_ID.ADMOB_BigBANNER_AD_ID[1], AdPosition.Center, "bigbanner");
            LowBigBanner = new AdmobMonotization(TestAdmob_ID.ADMOB_BigBANNER_AD_ID[2], AdPosition.Center, "bigbanner");

            HighAppOpen = new AdmobMonotization(TestAdmob_ID.AppOpenAdIds[0], 0);
            MedAppOpen = new AdmobMonotization(TestAdmob_ID.AppOpenAdIds[1], 1);
            LowAppOpen = new AdmobMonotization(TestAdmob_ID.AppOpenAdIds[2], 2);
        }
        else
        {
            HighTopBanner = new AdmobMonotization(AndroidAdmob_ID.ADMOB_TopBANNER_AD_ID[0]);
            MedTopBanner = new AdmobMonotization(AndroidAdmob_ID.ADMOB_TopBANNER_AD_ID[1]);
            LowTopBanner = new AdmobMonotization(AndroidAdmob_ID.ADMOB_TopBANNER_AD_ID[2]);

            HighBottomBanner = new AdmobMonotization(AndroidAdmob_ID.ADMOB_BottomBANNER_AD_ID[0], AdPosition.Bottom);
            MedBottomBanner = new AdmobMonotization(AndroidAdmob_ID.ADMOB_BottomBANNER_AD_ID[1], AdPosition.Bottom);
            LowBottomBanner = new AdmobMonotization(AndroidAdmob_ID.ADMOB_BottomBANNER_AD_ID[2], AdPosition.Bottom);

            HighBigBanner = new AdmobMonotization(AndroidAdmob_ID.ADMOB_BigBANNER_AD_ID[0], AdPosition.Center, "bigbanner");
            MedBigBanner = new AdmobMonotization(AndroidAdmob_ID.ADMOB_BigBANNER_AD_ID[1], AdPosition.Center, "bigbanner");
            LowBigBanner = new AdmobMonotization(AndroidAdmob_ID.ADMOB_BigBANNER_AD_ID[2], AdPosition.Center, "bigbanner");

            HighAppOpen = new AdmobMonotization(AndroidAdmob_ID.AppOpenAdIds[0], 0);
            MedAppOpen = new AdmobMonotization(AndroidAdmob_ID.AppOpenAdIds[1], 1);
            LowAppOpen = new AdmobMonotization(AndroidAdmob_ID.AppOpenAdIds[2], 2);
        }


    }
    void checkInitilization()
    {
        if (!isAdmobInitialized)
            AdmobInit();
        else if(!Check_Firebase)
            StartCoroutine(FireBaseInitialize());
        
    }
    bool OneTimeLoad = false;
    void LoadAllAds()
    {
        if (isAdmobInitialized)
        {
            if (!OneTimeLoad)
            {
                OneTimeLoad= true;
                LoadAppOpenAd();
                Invoke(nameof(ShowAppOpenAd), 6.5f);
                Invoke(nameof(LoadTopBanner), 1f);
                Invoke(nameof(ShowTopBanner), 2.5f);
                Invoke(nameof(LoadBottomBanner), 3.5f);
                Invoke(nameof(ShowBottomBanner), 5f);
                Invoke(nameof(LoadBigBanner), 11);
            }
            
        }
        else
        {
            AdmobInit();
        }
        if (InitSucceded)
        {
            Invoke(nameof(LoadInterstitial), 8);
            Invoke(nameof(LoadRewarded_Ad), 9);
        }
        else
        {
            OnInitializeMax();
        }
    }
    
    void MediationAdapterConsent(string AdapterClassname)
    {
        if (AdapterClassname.Contains("MobileAds"))
        {
            isAdmobInitialized = true;
            Debug.Log("GG >> Admob consent is send" + isAdmobInitialized);
            AdmobText.text = "Admob Initialized";
            // load ad
        }

    }
    void OnClose_consentForm()
    {
       // Track.text = "OnClose_consentForm call " + Time.timeScale;

        Time.timeScale = 1;
        //if (loadingScreen)
        //    loadingScreen.ShowLoading();
        if (!ConsentPanelAlreadyShow)
        {
            AdmobText.text = "Admob Start";
            ConsentPanelAlreadyShow = true;
            AdmobInit();
        }
    }
    WaitForSecondsRealtime firebasedelay=new WaitForSecondsRealtime(.5f);
    IEnumerator FireBaseInitialize()
    {
        yield return firebasedelay;
        // Aqib

        if (FirebaseHandler.instance && !Check_Firebase)
            FirebaseHandler.instance.InitializeFirebase();
        else if(!InitSucceded)
            OnInitializeMax();
    }
    #region Get GDRP Consent


    ConsentForm _consentForm;

    void GetGDPR_Consent()
    {
        var debugSettings = new ConsentDebugSettings
        {
            // Geography appears as in EEA for debug devices.
            DebugGeography = DebugGeography.EEA,
            TestDeviceHashedIds = new List<string>
            {
                "7748b46d-458d-4c8b-bfb1-10ca1ad1abe1"
            }
        };

        // Here false means users are not under age.
        ConsentRequestParameters request = new ConsentRequestParameters
        {
            TagForUnderAgeOfConsent = false,
            ConsentDebugSettings = debugSettings,
        };

        // Check the current consent information status.
        Debug.Log("Call ConsentInfoUpdate");
        ConsentInformation.Update(request, OnConsentInfoUpdated);
    }
    int consentcount;
    public void OnConsentInfoUpdated(FormError error)
    {
        consentcount += 1;
        //NewLogsForconsent.text = "consentcount " + consentcount;
        if (error != null || ConsentPanelAlreadyShow)
        {
            OnClose_consentForm();

            // Handle the error.
            Debug.Log("Error" + error);
            //UnityEngine.Debug.LogError(error);
            return;
        }
        Debug.Log("OnConsentInfoUpdated run");
        if (ConsentInformation.IsConsentFormAvailable())
        {
            LoadConsentForm();
        }
        else
        {
            OnClose_consentForm();
        }

        // If the error is null, the consent information state was updated.
        // You are now ready to check if a form is available.
    }

    public void LoadConsentForm()
    {
        // Loads a consent form.
        Debug.Log("OnLoading call ConsentForm");
        ConsentForm.Load(OnLoadConsentForm);
    }
    public void OnLoadConsentForm(ConsentForm consentForm, FormError error)
    {
        if (error != null || ConsentPanelAlreadyShow)
        {
            OnClose_consentForm();
            // Handle the error.
            Debug.Log("Error On OnLoadConsentForm");
            //UnityEngine.Debug.LogError(error);
            return;
        }
        Debug.Log("OnLoadConsentForm run");
        // The consent form was loaded.
        // Save the consent form for future requests.
        _consentForm = consentForm;
        if(ConsentInformation.ConsentStatus == ConsentStatus.Required)
        {
            _consentForm.Show(OnShowForm);
        }
        
        if (ConsentInformation.ConsentStatus == ConsentStatus.Obtained)
        {
            PlayerPrefs.SetInt("GDPRConsentAd", 1);
            Debug.Log(" Consent Obtained ");
            OnClose_consentForm();
        }
        if (ConsentInformation.ConsentStatus == ConsentStatus.NotRequired)
        {
            PlayerPrefs.SetInt("GDPRConsentAd", 1);
            OnClose_consentForm();
        }
        if (ConsentInformation.ConsentStatus == ConsentStatus.Unknown)
        {
            OnClose_consentForm();
        }
        

    }


    public void OnShowForm(FormError error)
    {
        if (error != null)
        {
            OnClose_consentForm();
            // Handle the error.
            Debug.Log("Error On OnShowForm");
            UnityEngine.Debug.LogError(error);

            return;
        }
        Debug.Log("OnShowForm run");

        // Handle dismissal by reloading form.
        LoadConsentForm();
    }

    #endregion


    #region  Top Banner
    bool TopBannerLoadOneTime=false;
    bool TopBannerTextShow = false;
    public void LoadTopBanner()
    {
        if (RemoveAdsChecker())
            return;

        //Admob
        if (!TopBannerLoadOneTime)
        {
            HighTopBanner.AssignTopBannerPoition(AdPosition.Top);
            MedTopBanner.AssignTopBannerPoition(AdPosition.Top);
            LowTopBanner.AssignTopBannerPoition(AdPosition.Top);

            LHigh_InfoValue += 1;
            LMed_InfoValue += 1;
            LLow_InfoValue += 1;

           // LHigh_Info.text = "HighTopBanner LoadBanner " + LHigh_InfoValue;
            HighTopBanner.LoadTopBanner();
           // LMed_Info.text = "MedTopBanner LoadBanner " + LMed_InfoValue;
            MedTopBanner.LoadTopBanner();
          //  LLow_Info.text = "LowTopBanner LoadBanner " + LLow_InfoValue;
            LowTopBanner.LoadTopBanner();


            TopBannerLoadOneTime = true;
        }
        

    }


    public void ShowTopBanner()
    {
        if (RemoveAdsChecker())
            return;

        PriorityCheckTopBannerLoad();
    }

    void PriorityCheckTopBannerLoad()
    {
        if (!SwitchNextTopBannerLoadCheck(0))
        {
            if (!SwitchNextTopBannerLoadCheck(1))
            {
                if (!SwitchNextTopBannerLoadCheck(2))
                {
                    Invoke(nameof(ShowTopBanner), 5);
                }
                else
                {
                    Invoke(nameof(ShowTopBanner), 15);
                }
            }
            else
            {
                Invoke(nameof(ShowTopBanner), 30);
            }
        }
    }
    bool SwitchNextTopBannerLoadCheck(int Priority)
    {
        switch (Priority)
        {
            case 0:
                if (HighTopBanner.IsLoadTopBanner())
                {

                    if (!HighTopBanner.IsAlreadyShowTopBanner())
                    {
                      //  High_InfoValue += 1;
                        
                       // SHigh_InfoTextShow(string.Concat(" HighTopBanner Show " + High_InfoValue), TopBannerTextShow);
                        
                        CurrentTopBannerShow = 0;

                        bool HideTopBanner1 = HideTopBannerLoadCheck(1);
                        bool HideTopBanner2 = HideTopBannerLoadCheck(2);
                        HighTopBanner.ShowTopBanner();
                    }
                    else
                    {
                      //  High_InfoValue += 1;
                      //  SHigh_InfoTextShow(string.Concat(" Already HighTopBanner Show " + High_InfoValue), TopBannerTextShow);
                        
                    }

                    return true;
                }
                else
                {
                  //  LHigh_InfoValue += 1;
                  //  LHigh_Info.text = "HighTopBanner LoadBanner " + LHigh_InfoValue;
                   
                    HighTopBanner.LoadTopBanner();
                    return false;
                }

            case 1:
                if (MedTopBanner.IsLoadTopBanner())
                {
                    if (!MedTopBanner.IsAlreadyShowTopBanner())
                    {
                       // Med_InfoValue += 1;
                       // SMed_Info.text = "MedTopBanner Show " + Med_InfoValue;
                        CurrentTopBannerShow = 1;

                        bool HideTopBanner0 = HideTopBannerLoadCheck(0);
                        bool HideTopBanner2 = HideTopBannerLoadCheck(2);
                        MedTopBanner.ShowTopBanner();
                    }
                    else
                    {
                      //  Med_InfoValue += 1;
                      //  SMed_Info.text = "Already MedTopBanner Show" + Med_InfoValue;
                    }
                    return true;
                }
                else
                {
                  //  LMed_InfoValue += 1;
                   // LMed_Info.text = "MedTopBanner LoadBanner " + LMed_InfoValue;
                   
                    MedTopBanner.LoadTopBanner();

                    return false;
                }
            case 2:
                if (LowTopBanner.IsLoadTopBanner())
                {
                    if (!LowTopBanner.IsAlreadyShowTopBanner())
                    {
                      //  Low_InfoValue += 1;
                      //  SLow_Info.text = "LowTopBanner Show " + Low_InfoValue;
                        CurrentTopBannerShow = 2;

                        bool HideTopBanner0 = HideTopBannerLoadCheck(0);
                        bool HideTopBanner1 = HideTopBannerLoadCheck(1);
                        LowTopBanner.ShowTopBanner();
                    }
                    else
                    {
                      //  Low_InfoValue += 1;
                      //  SLow_Info.text = "Already LowTopBanner Show " + Low_InfoValue;
                    }
                    return true;
                }
                else
                {
                  //  LLow_InfoValue += 1;
                   // LLow_Info.text = "LowTopBanner LoadBanner " + LLow_InfoValue;

                    LowTopBanner.LoadTopBanner();
                    return false;
                }
            case 99:
                return false;
            default:
                return false;
        }
    }

    public void HideTopBanner()
    {
        if (!HideTopBannerLoadCheck(CurrentTopBannerShow))
        {
            if (!HideTopBannerLoadCheck(0))
            {
                if (!HideTopBannerLoadCheck(1))
                {
                    if (!HideTopBannerLoadCheck(2))
                    {
                    }
                }
            }
        }
    }

    bool HideTopBannerLoadCheck(int Priority)
    {

        switch (Priority)
        {
            case 0:

                if (HighTopBanner.IsLoadTopBanner())
                {
                    if (HighTopBanner.IsAlreadyShowTopBanner())
                    {

                       // High_HInfoValue += 1;
                       // SHigh_InfoTextShow(string.Concat(" HighTopBanner HideBanner " + High_InfoValue), TopBannerTextShow);
                        HighTopBanner.HideTopBanner();
                    }
                    else
                    {
                       // High_HInfoValue += 1;
                       // SHigh_InfoTextShow(string.Concat("already HighTopBanner HideBanner " + High_InfoValue), TopBannerTextShow);
                    }


                    return true;
                }
                else
                    return false;
            case 1:
                if (MedTopBanner.IsLoadTopBanner())
                {
                    if (MedTopBanner.IsAlreadyShowTopBanner())
                    {
                      //  Med_HInfoValue += 1;
                     //   Med_HInfo.text = "MedTopBanner HideBanner " + Med_HInfoValue;
                        MedTopBanner.HideTopBanner();
                    }
                    else
                    {
                       // Med_HInfoValue += 1;
                       // Med_HInfo.text = "Already MedTopBanner HideBanner " + Med_HInfoValue;
                    }


                    return true;
                }
                else
                    return false;
            case 2:
                if (LowTopBanner.IsLoadTopBanner())
                {
                    if (LowTopBanner.IsAlreadyShowTopBanner())
                    {
                        Low_HInfoValue += 1;
                        //&& LowBanner.IsAlreadyShowBanner()
                       // Low_HInfo.text = "LowTopBanner HideBanner " + Low_HInfoValue;
                        LowTopBanner.HideTopBanner();
                    }
                    else
                    {
                      //  Low_HInfoValue += 1;
                       // Low_HInfo.text = "Already LowTopBanner HideBanner " + Low_HInfoValue;
                    }


                    return true;
                }
                else
                    return false;
            case 99:
                return false;
            default:
                return false;
        }
    }
    int IsTopBannerAlreadyShowIndex;
    int CheckTopBannerAlreadyLoad()
    {
        if (HighTopBanner.IsAlreadyShowTopBanner() || MedTopBanner.IsAlreadyShowTopBanner() || LowTopBanner.IsAlreadyShowTopBanner())
        {
            IsTopBannerAlreadyShowIndex = 1;
            return 1;
        }
        else
        {
            IsTopBannerAlreadyShowIndex = 0;
            return 0;
        }
    }
    #endregion
    #region Bottom Banner
    bool BottomBannerLoadOneTime = false;
    bool BottomBannerTextShow = false;
    public void LoadBottomBanner()
    {
        if (RemoveAdsChecker())
            return;

        //Admob
        // Banners.AssignBannerPoition();
        if (!BottomBannerLoadOneTime)
        {
            BottomBannerLoadOneTime = true;
            HighBottomBanner.AssignBottomBannerPoition(AdPosition.Bottom);
            MedBottomBanner.AssignBottomBannerPoition(AdPosition.Bottom);
            LowBottomBanner.AssignBottomBannerPoition(AdPosition.Bottom);

            LHigh_InfoValue += 1;
            LMed_InfoValue += 1;
            LLow_InfoValue += 1;

            LHigh_Info.text = "HighBottomBanner LoadBanner " + LHigh_InfoValue;
            HighBottomBanner.LoadBottomBanner();
            LMed_Info.text = "MedBottomBanner LoadBanner " + LMed_InfoValue;
            MedBottomBanner.LoadBottomBanner();
            LLow_Info.text = "LowBottomBanner LoadBanner " + LLow_InfoValue;
            LowBottomBanner.LoadBottomBanner();


           // StartCoroutine(IsBottomBannerLoad());
        }
            
    }
    WaitForSecondsRealtime LDelaysecondsRealtime = new WaitForSecondsRealtime(5);
    WaitForSecondsRealtime MDelaysecondsRealtime = new WaitForSecondsRealtime(7);
    //IEnumerator IsBottomBannerLoad()
    //{
    //    yield return LDelaysecondsRealtime;
    //    if (!HighBottomBanner.IsLoadBottomBanner())
    //    {
    //        yield return MDelaysecondsRealtime;
    //        if (!MedBottomBanner.IsLoadBottomBanner())
    //        {
    //            yield return MDelaysecondsRealtime;
    //            if (!LowBottomBanner.IsLoadBottomBanner())
    //            {
    //                StartCoroutine(IsBottomBannerLoad());
    //            }
    //            else
    //            {
    //                yield return LDelaysecondsRealtime;
    //                StartCoroutine(IsBottomBannerLoad());
    //            }
    //        }
    //        else
    //        {
    //            yield return MDelaysecondsRealtime;
    //            StartCoroutine(IsBottomBannerLoad());
    //        }
    //    }
    //}
    public void ShowBottomBanner()
    {
        if (RemoveAdsChecker())
            return;

        //BottomBannerAdPosition = adPosition;
        PriorityCheckBottomBannerLoad();
    }
    
    void PriorityCheckBottomBannerLoad()
    {
        if (!SwitchNextBottomBannerLoadCheck(0))
        {
            if (!SwitchNextBottomBannerLoadCheck(1))
            {
                if (!SwitchNextBottomBannerLoadCheck(2))
                {
                    Invoke(nameof(ShowBottomBanner), 5);
                }
                else
                {
                    Invoke(nameof(ShowBottomBanner), 15);
                }
            }
            else
            {
                Invoke(nameof(ShowBottomBanner), 30);
            }
        }
    }
    bool SwitchNextBottomBannerLoadCheck(int Priority)
    {
        switch (Priority)
        {
            case 0:
                if (HighBottomBanner.IsLoadBottomBanner())
                {

                    if (!HighBottomBanner.IsAlreadyShowBottomBanner())
                    {
                        High_InfoValue += 1;
                        SHigh_InfoTextShow(string.Concat("HighBottomBanner Show " + High_InfoValue), BottomBannerTextShow);
                        
                        CurrentBottomBannerShow = 0;

                        bool value01 = HideBottomBannerLoadCheck(1);
                        bool value02 = HideBottomBannerLoadCheck(2);
                        HighBottomBanner.ChangePositionBottomBanner(BottomBannerAdPosition);
                        BottomBannerTextShow = true;
                        HighBottomBanner.ShowBottomBanner();
                    }
                    else
                    {
                        HighBottomBanner.ChangePositionBottomBanner(BottomBannerAdPosition);
                        High_InfoValue += 1;
                        SHigh_InfoTextShow(string.Concat("Already HighBottomBanner Show " + High_InfoValue), BottomBannerTextShow);
                        
                    }

                    return true;
                }
                else
                {
                    LHigh_InfoValue += 1;
                    LHigh_Info.text = "HighBanner LoadBottomBanner " + LHigh_InfoValue;

                    return false;
                }

            case 1:
                if (MedBottomBanner.IsLoadBottomBanner())
                {

                    if (!MedBottomBanner.IsAlreadyShowBottomBanner())
                    {
                        Med_InfoValue += 1;
                        SMed_Info.text = "MedBottomBanner Show " + Med_InfoValue;
                        CurrentBottomBannerShow = 1;

                        bool value00 = HideBottomBannerLoadCheck(0);
                        bool value02 = HideBottomBannerLoadCheck(2);

                        MedBottomBanner.ChangePositionBottomBanner(BottomBannerAdPosition);
                        MedBottomBanner.ShowBottomBanner();
                    }
                    else
                    {
                        MedBottomBanner.ChangePositionBottomBanner(BottomBannerAdPosition);
                        Med_InfoValue += 1;
                        SMed_Info.text = "Already MedBottomBanner Show" + Med_InfoValue;
                    }
                    return true;
                }
                else
                {
                    LMed_InfoValue += 1;
                    LMed_Info.text = "MedBottomBanner LoadBanner " + LMed_InfoValue;


                    return false;
                }
            case 2:
                if (LowBottomBanner.IsLoadBottomBanner())
                {
                    if (!LowBottomBanner.IsAlreadyShowBottomBanner())
                    {
                        Low_InfoValue += 1;
                        SLow_Info.text = "LowBottomBanner Show " + Low_InfoValue;
                        CurrentBottomBannerShow = 2;

                        bool value00 = HideBottomBannerLoadCheck(0);
                        bool value01 = HideBottomBannerLoadCheck(1);

                        LowBottomBanner.ChangePositionBottomBanner(BottomBannerAdPosition);

                        LowBottomBanner.ShowBottomBanner();
                    }
                    else
                    {
                        LowBottomBanner.ChangePositionBottomBanner(BottomBannerAdPosition);
                        Low_InfoValue += 1;
                        SLow_Info.text = "Already LowBottomBanner Show " + Low_InfoValue;
                    }
                    return true;
                }
                else
                {
                    LLow_InfoValue += 1;
                    LLow_Info.text = "LowBanner LoadBottomBanner " + LLow_InfoValue;

                    return false;
                }
            case 99:
                return false;
            default:
                return false;
        }
    }
    //void PriorityBanner(int priority, int Position)
    //{
    //    switch (priority)
    //    {
    //        case 0:

    //            break;
    //        case 1:
    //            if (!bannerAlreadyShown)
    //            {
    //                bannerAlreadyShown = true;
    //                Banners.BannerPositionIndex = Position;
    //                Banners.AssignBannerPoition();
    //                Banners.ShowBanner();
    //                //Banners.ChangePositionBanner();
    //            }
    //            else
    //            {
    //                Banners.BannerPositionIndex = Position;
    //                Banners.ChangePositionBanner();
    //            }
    //            break;
    //    }
    //}
    public void HideBottomBanner()
    {
        if (!HideBottomBannerLoadCheck(CurrentBottomBannerShow))
        {
            if (!HideBottomBannerLoadCheck(0))
            {
                if (!HideBottomBannerLoadCheck(1))
                {
                    if (!HideBottomBannerLoadCheck(2))
                    {
                    }
                }
            }
        }
    }

    bool HideBottomBannerLoadCheck(int Priority)
    {

        switch (Priority)
        {
            case 0:

                if (HighBottomBanner.IsLoadBottomBanner())
                {
                    if (HighBottomBanner.IsAlreadyShowBottomBanner())
                    {
                        BottomBannerTextShow = false;
                        High_HInfoValue += 1;
                        SHigh_InfoTextShow(string.Concat("HighBottomBanner HideBanner " + High_InfoValue), BottomBannerTextShow);
                        
                        HighBottomBanner.HideBottomBanner();
                    }
                    else
                    {
                        High_HInfoValue += 1;
                        SHigh_InfoTextShow(string.Concat("already HighBottomBanner HideBanner " + High_InfoValue), BottomBannerTextShow);
                        
                    }


                    return true;
                }
                else
                    return false;
            case 1:
                if (MedBottomBanner.IsLoadBottomBanner())
                {
                    if (MedBottomBanner.IsAlreadyShowBottomBanner())
                    {
                       // Med_HInfoValue += 1;
                      //  Med_HInfo.text = "MedBottomBanner HideBanner " + Med_HInfoValue;
                        MedBottomBanner.HideBottomBanner();
                    }
                    else
                    {
                        Med_HInfoValue += 1;
                        Med_HInfo.text = "Already MedBottomBanner HideBanner " + Med_HInfoValue;
                    }


                    return true;
                }
                else
                    return false;
            case 2:
                if (LowBottomBanner.IsLoadBottomBanner())
                {
                    if (LowBottomBanner.IsAlreadyShowBottomBanner())
                    {
                        Low_HInfoValue += 1;
                        //&& LowBanner.IsAlreadyShowBanner()
                        Low_HInfo.text = "LowBottomBanner HideBanner " + Low_HInfoValue;
                        LowBottomBanner.HideBottomBanner();
                    }
                    else
                    {
                        Low_HInfoValue += 1;
                        Low_HInfo.text = "Already LowBottomBanner HideBanner " + Low_HInfoValue;
                    }


                    return true;
                }
                else
                    return false;
            case 99:
                return false;
            default:
                return false;
        }
    }
    int IsBottomBannerAlreadyShowIndex;
    int CheckBottomBannerAlreadyLoad()
    {
        if (HighBottomBanner.IsAlreadyShowBottomBanner() || MedBottomBanner.IsAlreadyShowBottomBanner() || LowBottomBanner.IsAlreadyShowBottomBanner())
        {
            IsBottomBannerAlreadyShowIndex = 1;
            return 1;
        }
        else
        {
            IsBottomBannerAlreadyShowIndex = 0;
            return 0;
        }
    }
    #endregion
    #region Big Banner
    bool BigBannerLoadOneTime = false;
    bool S_H_BigBannerTextShow = false;
    public void LoadBigBanner()
    {
        if (RemoveAdsChecker())
            return;


        if (!BigBannerLoadOneTime)
        {
            BigBannerLoadOneTime = true;
            HighBigBanner.AssignBigBannerPoition(AdPosition.Center);
            MedBigBanner.AssignBigBannerPoition(AdPosition.Center);
            LowBigBanner.AssignBigBannerPoition(AdPosition.Center);

            LHigh_InfoValue += 1;
            LMed_InfoValue += 1;
            LLow_InfoValue += 1;

           // LHigh_Info.text = "HighBigBanner LoadBanner " + LHigh_InfoValue;
            HighBigBanner.LoadBigBanner();
           // LMed_Info.text = "MedBigBanner LoadBanner " + LMed_InfoValue;
            MedBigBanner.LoadBigBanner();
            //LLow_Info.text = "LowBigBanner LoadBanner " + LLow_InfoValue;
            LowBigBanner.LoadBigBanner();

            StartCoroutine(IsBigBannerLoad());
        }
        
    }
    //WaitForSecondsRealtime LDelaysecondsRealtime = new WaitForSecondsRealtime(5);
    //WaitForSecondsRealtime MDelaysecondsRealtime = new WaitForSecondsRealtime(7);
    IEnumerator IsBigBannerLoad()
    {
        yield return LDelaysecondsRealtime;
        if (!HighBigBanner.IsLoadBigBannerForLoop())
        {
            yield return MDelaysecondsRealtime;
            if (!MedBigBanner.IsLoadBigBannerForLoop())
            {
                yield return MDelaysecondsRealtime;
                if (!LowBigBanner.IsLoadBigBannerForLoop())
                {
                    StartCoroutine(IsBigBannerLoad());
                }
                else
                {
                    yield return LDelaysecondsRealtime;
                    StartCoroutine(IsBigBannerLoad());
                }
            }
            else
            {
                yield return MDelaysecondsRealtime;
                StartCoroutine(IsBigBannerLoad());
            }
        }
    }

    public void ShowBigBanner()
    {
        if (RemoveAdsChecker())
            return;

        PriorityCheckBigBannerLoad();
    }

    void PriorityCheckBigBannerLoad()
    {
        if (!SwitchNextBigBannerLoadCheck(0))
        {
            if (!SwitchNextBigBannerLoadCheck(1))
            {
                if (!SwitchNextBigBannerLoadCheck(2))
                {
                }
            }
        }
    }
    bool SwitchNextBigBannerLoadCheck(int Priority)
    {
        switch (Priority)
        {
            case 0:
                if (HighBigBanner.IsLoadBigBanner())
                {

                    if (!HighBigBanner.IsAlreadyShowBigBanner())
                    {
                       // High_InfoValue += 1;
                       // SHigh_InfoTextShow(string.Concat(" HighBigBanner Show " + High_InfoValue), S_H_BigBannerTextShow);
                        CurrentBigBannerShow = 0;

                        bool value01 = HideBigBannerLoadCheck(1);
                        bool value02 = HideBigBannerLoadCheck(2);
                        S_H_BigBannerTextShow = true;
                        HighBigBanner.ShowBigBanner();
                    }
                    else
                    {
                       // High_InfoValue += 1;
                        //SHigh_InfoTextShow(string.Concat("Already HighBigBanner Show " + High_InfoValue), S_H_BigBannerTextShow);
                    }

                    return true;
                }
                else
                {
                   // LHigh_InfoValue += 1;
                   // LHigh_Info.text = "HighBigBanner LoadBanner " + LHigh_InfoValue;
                    //HighBigBanner.LoadBigBanner();
                    return false;
                }

            case 1:
                if (MedBigBanner.IsLoadBigBanner())
                {
                    if (!MedBigBanner.IsAlreadyShowBigBanner())
                    {
                      //  Med_InfoValue += 1;
                       // SMed_Info.text = "MedBigBanner Show " + Med_InfoValue;
                        CurrentBigBannerShow = 1;

                        bool value00 = HideBigBannerLoadCheck(0);
                        bool value22 = HideBigBannerLoadCheck(2);
                        MedBigBanner.ShowBigBanner();

                    }
                    else
                    {
                      //  Med_InfoValue += 1;
                       // SMed_Info.text = "Already MedBigBanner Show" + Med_InfoValue;
                    }
                    return true;
                }
                else
                {
                   // LMed_InfoValue += 1;
                  //  LMed_Info.text = "MedBigBanner LoadBanner " + LMed_InfoValue;
                    //MedBigBanner.LoadBigBanner();

                    return false;
                }
            case 2:
                if (LowBigBanner.IsLoadBigBanner())
                {
                    if (!LowBigBanner.IsAlreadyShowBigBanner())
                    {
                     //   Low_InfoValue += 1;
                      //  SLow_Info.text = "LowBigBanner Show " + Low_InfoValue;
                        CurrentBigBannerShow = 2;

                        bool value00 = HideBigBannerLoadCheck(0);
                        bool value01 = HideBigBannerLoadCheck(1);
                        LowBigBanner.ShowBigBanner();
                    }
                    else
                    {
                     //   Low_InfoValue += 1;
                     //   SLow_Info.text = "Already LowBigBanner Show " + Low_InfoValue;
                    }
                    return true;
                }
                else
                {
                  //  LLow_InfoValue += 1;
                  //  LLow_Info.text = "LowBigBanner LoadBanner " + LLow_InfoValue;
                    //Invoke(nameof(IsBigBannerLoad), 10);
                    //LowBigBanner.LoadBigBanner();
                    return false;
                }
            case 99:
                return false;
            default:
                return false;
        }
    }

    public void HideBigBanner()
    {
        if (!HideBigBannerLoadCheck(CurrentBigBannerShow))
        {
            if (!HideBigBannerLoadCheck(0))
            {
                if (!HideBigBannerLoadCheck(1))
                {
                    if (!HideBigBannerLoadCheck(2))
                    {
                    }
                }
            }
        }
    }

    bool HideBigBannerLoadCheck(int Priority)
    {

        switch (Priority)
        {
            case 0:

                if (HighBigBanner.IsLoadBigBanner())
                {
                    if (HighBigBanner.IsAlreadyShowBigBanner())
                    {
                      //  Low_HInfoValue += 1;
                       
                       // Low_HInfo.text = "HighBigBanner HideBanner " + Low_HInfoValue;
                        
                        HighBigBanner.HideBigBanner();
                    }
                    else
                    {
                      //  Low_HInfoValue += 1;
                       // Low_HInfo.text = "Already LowBigBanner HideBanner " + Low_HInfoValue;
                    }
                    return true;
                }
                else
                    return false;
            case 1:
                if (MedBigBanner.IsLoadBigBanner())
                {

                    if (MedBigBanner.IsAlreadyShowBigBanner())
                    {
                       // Low_HInfoValue += 1;
                       
                      //  Low_HInfo.text = "LowBigBanner HideBanner " + Low_HInfoValue;
                        MedBigBanner.HideBigBanner();
                    }
                    else
                    {
                       // Low_HInfoValue += 1;
                       // Low_HInfo.text = "Already LowBigBanner HideBanner " + Low_HInfoValue;
                    }

                    return true;
                }
                else
                    return false;
            case 2:
                if (LowBigBanner.IsLoadBigBanner())
                {
                    if (LowBigBanner.IsAlreadyShowBigBanner())
                    {
                       // Low_HInfoValue += 1;
                       
                       // Low_HInfo.text = "LowBigBanner HideBanner " + Low_HInfoValue;
                        LowBigBanner.HideBigBanner();
                    }
                    else
                    {
                      //  Low_HInfoValue += 1;
                     //   Low_HInfo.text = "Already LowBigBanner HideBanner " + Low_HInfoValue;
                    }


                    return true;
                }
                else
                    return false;
            case 99:
                return false;
            default:
                return false;
        }
    }
    int IsBigBannerAlreadyShowIndex;
    int CheckBigBannerAlreadyLoad()
    {
        if (HighBigBanner.IsAlreadyShowBigBanner() || MedBigBanner.IsAlreadyShowBigBanner() || LowBigBanner.IsAlreadyShowBigBanner())
        {
            IsBigBannerAlreadyShowIndex = 1;
            return 1;
        }
        else
        {
            IsBigBannerAlreadyShowIndex = 0;
            return 0;
        }


    }
    #endregion

    #region AppOpen Ad
    public void LoadAppOpenAd()
    {
        if (RemoveAdsChecker())
            return;

        //Admob
        LHigh_InfoValue += 1;
        LHigh_Info.text = "Load HighAppOpen " + LHigh_InfoValue;
        HighAppOpen.LoadAppOpenAd();
        LMed_InfoValue += 1;
        LMed_Info.text = "Load MedAppOpen " + LMed_InfoValue;
        MedAppOpen.LoadAppOpenAd();
        LLow_InfoValue += 1;
        LLow_Info.text = "Load LowAppOpen " + LLow_InfoValue;
        LowAppOpen.LoadAppOpenAd();
    }
    public void ShowAppOpenAd()
    {
        if (RemoveAdsChecker())
            return;

        PrioritySettingAppOpen();
    }
    void PrioritySettingAppOpen()
    {
        if (!SwitchAppOpen(0))
        {
            if (!SwitchAppOpen(1))
            {
                if (!SwitchAppOpen(2))
                {
                }
            }
        }
    }
    void HideAllBanners()
    {
        if (CheckBigBannerAlreadyLoad() == 1)
            HideBigBannerLoadCheck(CurrentBigBannerShow);

        if (CheckBottomBannerAlreadyLoad() == 1)
            HideBottomBannerLoadCheck(CurrentBottomBannerShow);

        if (CheckTopBannerAlreadyLoad() == 1)
            HideTopBannerLoadCheck(CurrentTopBannerShow);


    }
    void ShowClosedBannersAll()
    {
        if (IsBigBannerAlreadyShowIndex == 1)
        {
            bool banner02 = SwitchNextBigBannerLoadCheck(CurrentBigBannerShow);
        }


        if (IsBottomBannerAlreadyShowIndex == 1)
        {
            bool banner01 = SwitchNextBottomBannerLoadCheck(CurrentBottomBannerShow);
        }


        if (IsTopBannerAlreadyShowIndex == 1)
        {
            bool banner00 = SwitchNextTopBannerLoadCheck(CurrentTopBannerShow);
        }



    }
    bool SwitchAppOpen(int Priority)
    {
        switch (Priority)
        {

            case 0:
                if (HighAppOpen.IsAppOpenLoaded())
                {
                    ActiveAppOpenImage();
                    HideAllBanners();
                    High_InfoValue += 1;
                    SHigh_Info.text = "Show HighAppOpen " + High_InfoValue;
                    ForeGroundedAD = true;
                    HighAppOpen.ShowAppOpen();
                    ShowClosedBannersAll();

                    DeactiveAppOpenImage();
                    return true;
                }
                else
                {
                    LHigh_InfoValue += 1;
                    LHigh_Info.text = "Load HighAppOpen " + LHigh_InfoValue;
                    HighAppOpen.LoadAppOpenAd();
                    return false;
                }

            case 1:
                if (MedAppOpen.IsAppOpenLoaded())
                {
                    ActiveAppOpenImage();
                    HideAllBanners();
                    Med_InfoValue += 1;
                    SMed_Info.text = "Show MedAppOpen " + Med_InfoValue;
                    ForeGroundedAD = true;
                    MedAppOpen.ShowAppOpen();
                    ShowClosedBannersAll();

                    DeactiveAppOpenImage();
                    return true;
                }
                else
                {
                    LMed_InfoValue += 1;
                    LMed_Info.text = "Load MedAppOpen " + LMed_InfoValue;
                    MedAppOpen.LoadAppOpenAd();
                    return false;
                }
            case 2:
                if (LowAppOpen.IsAppOpenLoaded())
                {
                    ActiveAppOpenImage();
                    HideAllBanners();
                    Low_InfoValue += 1;
                    SLow_Info.text = "Show LowAppOpen " + Low_InfoValue;
                    ForeGroundedAD = true;
                    LowAppOpen.ShowAppOpen();
                    ShowClosedBannersAll();

                    DeactiveAppOpenImage();
                    return true;
                }
                else
                {
                    LLow_InfoValue += 1;
                    LLow_Info.text = "Load LowAppOpen " + LLow_InfoValue;
                    LowAppOpen.LoadAppOpenAd();
                    ForeGroundedAD = true;
                    return false;
                }
            case 99:
                return false;
            default:
                return false;
        }
    }
    void ActiveAppOpenImage()
    {
        AppOpenLoading.SetActive(true);
        Canves.SetActive(true);

    }
    void DeactiveAppOpenImage()
    {
        AppOpenLoading.SetActive(false);
        Canves.SetActive(false);
    }
    private void OnApplicationPause(bool isPaused)
    {
        if (!isPaused)
        {

            if (SceneManager.GetActiveScene().buildIndex == 0) //SceneManager.GetActiveScene().buildIndex == 0
            {
                return;
            }
            if (!ForeGroundedAD)
            {
                valueif += 1;
                MisloadInfo.text = ForeGroundedAD + " if ForeGroundedAD  " + valueif;
                //Debug.LogError("if  " + ForeGroundedAD);
                ForeGroundedAD = true;
                ShowAppOpenAd();
            }
            else
            {
                valueelse += 1;
                HisloadInfo.text = ForeGroundedAD + " else ForeGroundedAD " + valueelse;

                //Debug.LogError("Else  "+ ForeGroundedAD);
                ForeGroundedAD = false;
            }
        }
    }
    int valueif = 0;
    int valueelse = 0;
    public void GamePause()
    {
        Time.timeScale = 0;
    }
    public void GameResume()
    {
        Time.timeScale = 1;

    }
    #endregion


    #endregion
    bool checkInternet()
    {
        if (Application.internetReachability == NetworkReachability.ReachableViaCarrierDataNetwork
            || Application.internetReachability == NetworkReachability.ReachableViaLocalAreaNetwork)
            return true;
        else
            return false;
    }
   public void AdPurchased()
    {
        RemoveAds = true;
        HideBottomBanner();
        HideTopBanner();
        HideBigBanner();
    }
    bool RemoveAdsChecker()
    {
        if (RemoveAds)
            return true;
        else
            return false;
    }
    void SHigh_InfoTextShow(string value,bool Show)
    {
        if (!Show)
        {
            SHigh_Info.text = value;
        }
    }

    #region Max

    public void OnInitializeMax()
    {
        if (!InitSucceded)
        {
            MaxSdk.SetHasUserConsent(true);
            FirbaseText.text = "Max initializing";
            MaxSdk.SetSdkKey(SdkKey);
            MaxSdk.SetTestDeviceAdvertisingIdentifiers(TestDevices);
            MaxSdk.InitializeSdk();

            Debug.Log("InitCalled");
            //Track.text = "OnInitialize Max call " + Time.timeScale;
            MaxSdkCallbacks.OnSdkInitializedEvent += (MaxSdkBase.SdkConfiguration sdkConfiguration) =>
            {

                InitSucceded = true;
                //Debug.Log("InitSuccess");
                FirbaseText.text = "Max initialized";
                LoadAllAds();
                //MaxSdk.LoadAppOpenAd(AppOpenID);
                //Invoke(nameof(OnLoadAdaptiveBanner), 1);
                //Invoke(nameof(OnLoadSmallBanner), 2);
                // Track.text = "Ads  Max call " + Time.timeScale;
                MaxSdkCallbacks.Interstitial.OnAdHiddenEvent += MaxOnInterstitialHiddenEvent;
                MaxSdkCallbacks.Interstitial.OnAdLoadedEvent += MaxOnInterstitialLoadedHiddenEvent;
                MaxSdkCallbacks.Interstitial.OnAdRevenuePaidEvent += OnAdInterRevenuePaidEvent;



                MaxSdkCallbacks.Rewarded.OnAdHiddenEvent += OnRewardedAdHiddenEvent;
                MaxSdkCallbacks.Rewarded.OnAdDisplayedEvent += OnAdDisplayed;
                MaxSdkCallbacks.Rewarded.OnAdRevenuePaidEvent += OnAdRewardRevenuePaidEvent;
                MaxSdkCallbacks.AppOpen.OnAdRevenuePaidEvent += OnAdAppopenRevenuePaidEvent;
                // AppLovin SDK is initialized, start loading ads

            };
        }
        

        
    }
    private void OnAdDisplayed(string arg1, MaxSdkBase.AdInfo arg2)
    {
        Debug.Log("Rewarded ad displayed.");
        isRewarded = false;  // Reset flag when the ad is displayed
    }
    
    #region Max Events Call
    private void OnRewardedAdHiddenEvent(string arg1, MaxSdkBase.AdInfo arg2)
    {
        if (!isRewarded)
        {
            if (NotRewardHandle !=null)
                NotRewardHandle.Invoke();
        }
        
        ShowRewardPanel(false);
        MaxSdk.LoadRewardedAd(RewardedID);
    }
    private void MaxOnInterstitialLoadedHiddenEvent(string arg1, MaxSdkBase.AdInfo arg2)
    {
        IsInterstitialAdReady = true;
    }
    private void MaxOnInterstitialHiddenEvent(string arg1, MaxSdkBase.AdInfo arg2)
    {
        ShowRewardPanel(false);
        IsInterstitialAdReady = false;
        MaxSdk.LoadInterstitial(InterID);
    }
    public bool CompeleteInter;
    private void OnAdInterRevenuePaidEvent(string adUnitId, MaxSdkBase.AdInfo impressionData)
    {

        ReportRevenue_Applovin_SE(impressionData, AdType.Interstitial_Ads);
    }
    private void OnAdRewardRevenuePaidEvent(string adUnitId, MaxSdkBase.AdInfo impressionData)
    {
        ReportRevenue_Applovin_SE(impressionData, AdType.Rewarded_Video_Ads);
    }
    private void OnAdAppopenRevenuePaidEvent(string adUnitId, MaxSdkBase.AdInfo impressionData)
    {
        ReportRevenue_Applovin_SE(impressionData, AdType.AppOpen_Ads);
    }
    private void OnRewardedAdReceivedRewardEvent(string arg1, MaxSdkBase.Reward arg2, MaxSdkBase.AdInfo arg3)
    {
        
        isRewarded = true;
    }
    #endregion
    #region Max Interstitial Call
    public void LoadInterstitial()
    {
        if (!InitSucceded)
        {
            OnInitializeMax();
            return;
        }
            
        
        if (!DontShowAds)
        {
            
            if (!MaxSdk.IsInterstitialReady(InterID))
                MaxSdk.LoadInterstitial(InterID);
        }
        
    }
    public void InterstitialLoad_Show()
    {
        if (!DontShowAds)
            StartCoroutine(ShowInterstetialDelay());
    }
    WaitForSecondsRealtime secondsRealtime = new WaitForSecondsRealtime(.5f);
    IEnumerator ShowInterstetialDelay()
    {
        LoadInterstitial();
        yield return secondsRealtime;
        ShowInterstitial();
    }
     void ShowInterstitial()
    {
        if (!InitSucceded || RemoveAdsChecker() || DontShowAds) return;
        Log("AD Inter Called");

        if (MaxSdk.IsInterstitialReady(InterID))
        {
            ForeGroundedAD = true;
            MaxSdk.ShowInterstitial(InterID);
            setTimeForInterAds();
        }
        else
        {
            MaxSdk.LoadInterstitial(InterID);
        }
    }
    #endregion
    #region Max Reward call
    public void LoadRewarded_Ad()
    {
        if (!DontShowAds)
            MaxSdk.LoadRewardedAd(RewardedID);
    }
    public bool CanShowReward()
    {
        return MaxSdk.IsRewardedAdReady(RewardedID);
    }

    public void ShowReward_Video()
    {
        Show_RewardedVideo(RewardHandle, NotRewardHandle);
    }

    public void Show_RewardedVideo(Action _Reward, Action _NotReward)
    {
        if (!InitSucceded)
        {
            OnInitializeMax();
            return;
        }


        if (!InitSucceded || DontShowAds) return;
        Log("AD Rewarded Called");

        MaxSdkCallbacks.Rewarded.OnAdReceivedRewardEvent += OnRewardedAdReceivedRewardEvent;
        if (MaxSdk.IsRewardedAdReady(RewardedID))
        {
            RewardHandle = _Reward;
            NotRewardHandle = _NotReward;
            ForeGroundedAD = true;
            MaxSdk.ShowRewardedAd(RewardedID);
        }
        else
        {
            MaxSdk.LoadRewardedAd(RewardedID);
        }
    }
    public bool IsRewardedVideo_Available()
    {
        if (!InitSucceded) return false;

        return MaxSdk.IsRewardedAdReady(RewardedID);
    }
    bool OneTimeReward = false;
    public void ShowRewardVideo(Action _Reward)
    {
        if (!InitSucceded)
        {
            OnInitializeMax();
            return;
        }


        if (!OneTimeReward)
        {
            OneTimeReward = true;
            StartCoroutine(ShowRewardedDelay(_Reward));
        }
        else
        {
            StartCoroutine(ResetDelay());
        }

    }
    WaitForSecondsRealtime ResetDelayRealtime = new WaitForSecondsRealtime(2f);

    IEnumerator ResetDelay()
    {

        yield return ResetDelayRealtime;
        OneTimeReward = false;
    }
    
    IEnumerator ShowRewardedDelay(Action _Reward)
    {

        if (!InitSucceded || DontShowAds) yield return null;


        Log("AD Rewarded Called");
        MaxSdk.LoadRewardedAd(RewardedID);
        yield return secondsRealtime;


        MaxSdkCallbacks.Rewarded.OnAdReceivedRewardEvent += OnRewardedAdReceivedRewardEvent;
        if (MaxSdk.IsRewardedAdReady(RewardedID))
        {
            RewardHandle = _Reward;
            ForeGroundedAD = true;
            MaxSdk.ShowRewardedAd(RewardedID);
        }
        else
        {
            MaxSdk.LoadRewardedAd(RewardedID);
        }
        yield return secondsRealtime;
        OneTimeReward = false;
    }
    #endregion



    public void Update()
    {
        if (isRewarded)
        {
            isRewarded = false;
            if (RewardHandle != null)
            {
                RewardHandle.Invoke();
                NotRewardHandle = null;
            }
        }
    }

   
    #endregion
    public void Log(string text)
    {
        Debug.Log(text);
        if (_log)
        {
            _log.text = text;
        }
    }
    
    public bool isDealayCompleteForAds()
    {
        double secondsPassed = (DateTime.UtcNow - Time1ForAds).TotalSeconds;

        if (secondsPassed > 5)
        {
            setTime1ForAds();
            return true;
        }
        return false;
    }

    public void setTime1ForAds()
    {
        Time1ForAds = DateTime.UtcNow;
    }
    public void setTimeForInterAds()
    {
        Time1ForAds = DateTime.UtcNow;
    }
    
    WaitForSecondsRealtime delaycheckInternet = new WaitForSecondsRealtime(1);
    IEnumerator Btn_Internet()
    {
        if (Application.internetReachability != NetworkReachability.NotReachable
         || Application.internetReachability == NetworkReachability.ReachableViaLocalAreaNetwork
         || Application.internetReachability == NetworkReachability.ReachableViaCarrierDataNetwork)
        {
            // 1st = Debug.Log("! ( No ) Yes internet connection");
            // 2nd = Debug.Log("Internet is available via Wi-Fi");
            // 3rd = Debug.Log("Internet is available via mobile data");
            Internet = true;
            print("Internet == Yes");
        }
        else
        {

            NoInterNetPanelActive();
            Internet = false;
            print("Internet == No");
        }
        yield return delaycheckInternet;
        StartCoroutine(Btn_Internet());
        //Invoke(nameof(Btn_Internet), 1f);
    }

    
    void NoInterNetPanelActive()
    {
        

        NoInternetPanelLandscap.SetActive(true);

        Canves.SetActive(true);
        Time.timeScale = 0;
    }
    public void CloseNoInternetPanel()
    {
        if (Application.internetReachability != NetworkReachability.NotReachable
            || Application.internetReachability == NetworkReachability.ReachableViaLocalAreaNetwork
            || Application.internetReachability == NetworkReachability.ReachableViaCarrierDataNetwork)
        {
            NoInternetPanelLandscap.SetActive(false);
            Canves.SetActive(false);
            checkInitilization();
            Time.timeScale = 1;
        }

    }
    
    


    /// <summary>
    /// Create Ads objects.
    /// </summary>


    public void ShowRewardPanel(bool value)
    {
        
        Canves.SetActive(value);
        RewardLoadingPanel.SetActive(value);
    }

    public void ShowAlreadyBuyPanel()
    {

        StartCoroutine(AlreadyBuyProductDelay());
    }
    WaitForSecondsRealtime delayIAPAlready = new WaitForSecondsRealtime(2.3f);
    IEnumerator AlreadyBuyProductDelay()
    {
        Canves.SetActive(true);
        AlreadyBuyThisPanel.SetActive(true);
        yield return delayIAPAlready;
        Canves.SetActive(false);
        AlreadyBuyThisPanel.SetActive(false);
    }
    public void TryingtoInitializedAgain()
    {
        if (!isAdmobInitialized)
        {
            if (Application.internetReachability == NetworkReachability.ReachableViaCarrierDataNetwork || Application.internetReachability == NetworkReachability.ReachableViaLocalAreaNetwork)
            {
                if (trytoInitializeOnceMore)
                {
                    trytoInitializeOnceMore = false;

                    //initialize(true); 
                    Invoke(nameof(CanTryAgain), 20f);

                }
            }
        }
    }

    public void CanTryAgain()
    {
        trytoInitializeOnceMore = true;
    }
    #region soler Engin
    public void ReportRevenue_Applovin_SE(MaxSdkBase.AdInfo maxad, AdType format)
    {

        ImpressionAttributes impressionAttributes = new ImpressionAttributes();
        impressionAttributes.ad_platform = maxad.NetworkName;
        impressionAttributes.ad_id = maxad.AdUnitIdentifier;
        impressionAttributes.ad_type = (int)format;
        impressionAttributes.currency_type = "USD";
        impressionAttributes.ad_ecpm = maxad.Revenue * 1000.00;
        impressionAttributes.mediation_platform = "MAX";
        impressionAttributes.is_rendered = true;
        Analytics.trackIAI(impressionAttributes);
    }
    public void ReportRevenue_Admob_SE(string adString, ResponseInfo info, GoogleMobileAds.Api.AdValue adValue, AdType format)
    {

        ImpressionAttributes impressionAttributes = new ImpressionAttributes();

        // Set the ad platform to AdMob
        impressionAttributes.ad_platform = "admob";

        // Set the Ad Unit ID (adString passed to the function)
        impressionAttributes.ad_id = adString;

        // Set the Ad Type based on the format parameter (e.g., Banner, Interstitial, Rewarded)
        impressionAttributes.ad_type = (int)format;

        // Set the currency type (USD is common, or you can use the currency from adValue)
        impressionAttributes.currency_type = adValue.CurrencyCode ?? "USD";  // Default to USD if no currency is available

        // Set the eCPM value (multiply by 1000 to get the cost per thousand impressions)
        // You should set this based on your actual eCPM, or you can use the revenue provided by adValue.
        impressionAttributes.ad_ecpm = adValue.Value /1000; // adValue.Value is typically in the smallest unit (e.g., cents), so multiply by 1000

        // Set the mediation platform (AdMob in this case)
        impressionAttributes.mediation_platform = "admob";

        // Set if the ad is rendered (ad is visible to the user)
        impressionAttributes.is_rendered = true;

        // Track the impression using your analytics or tracking system
        Analytics.trackIAI(impressionAttributes);


    }
    private void setAdValue(string str, string val)
    {
        PlayerPrefs.SetString("tROAS" + str, val); // Saving Troas values
    }

    private string getAdValue(string str)
    {
        return PlayerPrefs.GetString("tROAS" + str, "0"); // Getting Troas values
    }
    #endregion

}
[Serializable]
public class AdmobId
{
    public string App_ID;
    [Header("APPOPEN_AD_ID")]
    public string[] AppOpenAdIds = new string[] {
        "ca-app-pub-3940256099942544/9257395921",  // Test ID AdMob App Open Ad ID (1st Priority)
        "ca-app-pub-3940256099942544/9257395921",                          //Test ID AdMob App Open Ad ID (2nd Priority) 
        "ca-app-pub-3940256099942544/9257395921"                           //Test ID AdMob App Open Ad ID (3rd Priority) 
    };

    public string[] ADMOB_TopBANNER_AD_ID = new string[] {
        "ca-app-pub-3940256099942544/9214589741",  // Test ID AdMob App Open Ad ID (1st Priority)
        "ca-app-pub-3940256099942544/9214589741",                          //Test ID AdMob App Open Ad ID (2nd Priority) 
        "ca-app-pub-3940256099942544/9214589741"                           //Test ID AdMob App Open Ad ID (3rd Priority) 
    };
    public string[] ADMOB_BottomBANNER_AD_ID = new string[] {
        "ca-app-pub-3940256099942544/6300978111",  // Test ID AdMob App Open Ad ID (1st Priority)
        "ca-app-pub-3940256099942544/6300978111",                          //Test ID AdMob App Open Ad ID (2nd Priority) 
        "ca-app-pub-3940256099942544/6300978111"                           //Test ID AdMob App Open Ad ID (3rd Priority) 
    };
    public string[] ADMOB_BigBANNER_AD_ID = new string[] {
        "ca-app-pub-3940256099942544/6300978111",  // Test ID AdMob App Open Ad ID (1st Priority)
        "ca-app-pub-3940256099942544/6300978111",                          //Test ID AdMob App Open Ad ID (2nd Priority) 
        "ca-app-pub-3940256099942544/6300978111"                           //Test ID AdMob App Open Ad ID (3rd Priority) 
    };

}
